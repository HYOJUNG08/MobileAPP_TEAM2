package com.example.tproject

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Fc2main : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fc2main)
    }
}